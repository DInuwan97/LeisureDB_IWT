<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="css/header.css">
<link rel="stylesheet" type="text/css" href="css/customer_profile.css">
<link rel="stylesheet" type="text/css" href="css/footer.css">


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->

 <script src="js/contentscript.js"></script> 


<style>


</style>

</head>






<!-- ---------------------header------------------header--------------------header--------------------header---------------------header--------- -->




<!-- ---footer----------------------------------------footer-----------------------------------------------footer--------------------------------footer----------------------------->

    	
      <div class="footer">
        <div class="news-letter clearfix">
          <center>


            <table border="0">
              <tr>
                <td><h1>Sign Up for Newsletter </h1></td>
                <td></td>
                <td><input type="Email" name="" placeholder="  Enter Your Email........"  required = ""></td>
                <td></td>
                <td><form method="POST" action="#"><button type="button" class="">SIGN UP</button></form></td>
              </tr>
            </table>
          
          </center>
          
        </div><!-- newslater-->


          <div class="down-footer">


       
              <div class="col">            
                    <div class="down-footer-col clearfix">
                        <h4 class="contact" style="font-size:25px;">Contact Us</h4>

                       

                        <table border="0">
                          <tr>
                            <td><i class="fas fa-map-marker-alt fa-2x" style="color: rgb(190, 35, 35);"></i></td>
                            <td></td>
                            <td class="city">NO:77,<br>Kandy Road,</td>
                          </tr>

                          <tr>
                              <td></td>
                               <td></td>
                              <td class="city">Malabe,<br>Sri Lanka.</td>  
                          </tr>

                          <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                          </tr>

                          <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                          </tr>

                          <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                          </tr>



                          <tr>
                            <td><i class="fas fa-phone-square fa-2x" style="color: rgb(32, 196, 32);"></i></td>
                            <td></td>
                            <td><a href="skype:0712184518?call">(+94) 71 2184 518</a></td>
                          </tr>


                          <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                          </tr>

                          <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                          </tr>

                          <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                          </tr>



                          <tr>
                            <td><i class="fas fa-envelope-square fa-2x" style="color: rgb(10, 110, 241)"></i></td>
                            <td></td>
                            <td><a href="mailto:info@thirtyfirstsoftwares.com">info@thirtyfirstsoftwares.com</a></td>
                          </tr>

                        
                        </table>


                    </div><!-- down-footer-col -->

                    <div class="down-footer-col clearfix">
                      <h4 style="font-size:23px;">Apply for Job Opportunities</h4>

                      <p>
                        <i class="fas fa-quote-left fa-1x"></i>
                                Leisure Stores ready to offer in ideal opprtunities,
                                those who are interested in Web designing,Mobile
                                Application developping & Financial Controllers.
                         <i class="fas fa-quote-right fa-1x"></i>

                      </p>
                      <br>

 <!--                  <center> -->
                  <table class="job" border="0">

                    <tr>
                      <td></td>
                      <td></td>
                      <td><i class="fas fa-hand-point-right fa-1x"></i></td>
                      <td><a href="job_opportunities.html">Web Administrators</a></td>

                    </tr>


                    <tr>
                      <td></td>
                      <td></td>
                      <td><i class="fas fa-hand-point-right fa-1x"></i></td>
                      <td><a href="job_opportunities.html">Finance Controllers</a></td>

                    </tr>

                    <tr>
                      <td></td>
                      <td></td>
                      <td><i class="fas fa-hand-point-right fa-1x"></i></td>
                      <td><a href="job_opportunities.html">Hybrid App Developpers</a></td>

                    </tr>


                  </table>
                <!--   </center> -->

                    </div><!-- down-footer-col -->


                    <div class="down-footer-col-last clearfix">
                         <h4 style="font-size:25px;">More Information</h4>

                         <table border="0">
                            <tr style="padding-right:40px; padding-left: 20px;">
                              <td><a href="aboutus.html">About us</a></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td><a href="#">Privacy Policy</a></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td><a href="feedback.html">Client's feedback</a></td>
                            </tr> 

                            <tr>
                              <td></td>
                              <td></td>
                            </tr>

                            <tr style="padding-right:40px; padding-left: 20px;">
                              <td><a href="#">Blog</a></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              
                              <td><a href="#">Site's New Updates</a></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td><a href="#">FAQ'S</a></td>
                            </tr>



                            <tr>
                              <td></td>
                              <td></td>
                            </tr>

                            <tr style="padding-right:40px; padding-left: 20px;">
                              <td><a href="#">News</td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>                       
                              <td><a href="#">Terms of sales</a></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td><a href="contactus.html">Find us on Google maps</a></td>
                            </tr>



                            <tr>
                              <td></td>
                              <td></td>
                            </tr>

                            <tr style="padding-right:40px; padding-left: 20px;">
                              <td><a href="#">Resorces</a></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>                            
                              <td><a href="#">Terms of sales</a></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                            </tr>




                         </table>
                         <br>

                         <div class="social-meadia clearfix">
                      <a href="#"><i class="fab fa-facebook-square fa-2x" id="fb"></i></a>
                            <a href="#"><i class="fab fa-instagram fa-2x" id="insta"></i></a>
                            <a href="#"><i class="fab fa-twitter-square fa-2x"></i></a>
                            <a href="#"><i class="fab fa-linkedin-square fa-2x"></i></a>
                            <a href="#"><i class="fab fa-google-plus-square fa-2x"></i></a>
                            <a href="#"><i class="fab fa-pinterest-square fa-2x"></i></a>
                            <a href="#"><i class="fas fa-rss-square fa-2x"></i></a>
                            <a href="#"><i class="fab fa-youtube fa-2x"></i></a>



                         </div><!-- social-meadia -->




                    </div><!-- down-footer-col-last -->
               </div><!-- col -->
            

              <h5>Copyrights &copy; 2018 | All Rights Reserved.</h5>

          </div><!-- down-footer -->




      </div><!-- footer -->



</div><!-- wrapper -->




</body>
</html>