<?php
    include('common/headeradmin.php');
?>

<!-- ---------------------header------------------header--------------------header--------------------header---------------------header--------- -->

<div class="body-page-admin">
	



    <dive class="page-title">
      <br>
      <h1><i class="fas fa-cogs fa-1x"></i>Customer Profile</h1>
    </dive><!-- page-title -->
         
    <div class="customer-profile">


    
      <div class="user-dashboard">
        <h1>Your Dashboard</h1>


        <div class="sub-dashboard">
          


        <div class="dashboard-message">
          
            <table border="0">
              <tr>
                <td><i class="fas fa-user-circle fa-3x"></i></td>
                <td><label>Jehan Frenando</label><p>Admin</p></td>
              </tr>
            </table>

            <p class="notification">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
              quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat.
            </p>
             
                <button class="admin-accept"><i class="fas fa-check-square"></i><!-- <a href="#dkalu">Accept</a> -->Accept</button>
                <button class="admin-reject"><i class="fas fa-times-circle"></i><!-- <a href="#dkalu">Accept</a> -->Reject</button>
                    
        </div><!-- dashboard-message -->
<!-- ------------------------------------------first massage---------------------------- -->
        <div class="dashboard-message">
          
            <table border="0">
              <tr>
                <td><i class="fas fa-user-circle fa-3x"></i></td>
                <td><label>Jehan Frenando</label><p>Admin</p></td>
              </tr>
            </table>

            <p class="notification">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
              quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat.
            </p>
             
                <button class="admin-accept"><i class="fas fa-check-square"></i><!-- <a href="#dkalu">Accept</a> -->Accept</button>
                <button class="admin-reject"><i class="fas fa-times-circle"></i><!-- <a href="#dkalu">Accept</a> -->Reject</button>
                    
        </div><!-- dashboard-message -->

            <div class="dashboard-message">
          
            <table border="0">
              <tr>
                <td><i class="fas fa-user-circle fa-3x"></i></td>
                <td><label>Jehan Frenando</label><p>Admin</p></td>
              </tr>
            </table>

            <p class="notification">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
              quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat.
            </p>
             
                <button class="admin-accept"><i class="fas fa-check-square"></i><!-- <a href="#dkalu">Accept</a> -->Accept</button>
                <button class="admin-reject"><i class="fas fa-times-circle"></i><!-- <a href="#dkalu">Accept</a> -->Reject</button>
                    
        </div><!-- dashboard-message -->


        
            <div class="dashboard-message">
          
            <table border="0">
              <tr>
                <td><i class="fas fa-user-circle fa-3x"></i></td>
                <td><label>Jehan Frenando</label><p>Admin</p></td>
              </tr>
            </table>

            <p class="notification">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
              quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat.
            </p>
             
                <button class="admin-accept"><i class="fas fa-check-square"></i><!-- <a href="#dkalu">Accept</a> -->Accept</button>
                <button class="admin-reject"><i class="fas fa-times-circle"></i><!-- <a href="#dkalu">Accept</a> -->Reject</button>
                    
        </div><!-- dashboard-message -->


        </div><!-- sub-dashboard -->


      </div><!-- dashbord -->

      <div class="user-settings clearfix">
        <h1>Customer's Control Panel</h1>

        <table border='0'>
          <tr>
            <td><a href="#"">Change Your Password</a></td>
          </tr>

          <tr>
            <td><a href="#">Update Your Account Information</a></td>
          </tr>
        </table>

        <h3><a href="#">Client's Feedback</a></h3>

        <br>
        <br>

        
    
        <div class="nav-title">
          <nav>
              <div class="nav-links">
                <ul>
                  <li><a href="#dashboard-message" id="manage-adds" class="active">Manage Adds</a></li>
                  <li><a href="#dashboard-message" id="manage-providers">Manage Providers</a></li>
                  <li><a href="#dashboard-message" id="manage-customers">Manage Customers</a></li>
                  <li><a href="#dashboard-message" id="owner-messages">Owner's Messages</a></li>
                </ul>
              </div><!-- nav-links -->
            </nav>
        </div><!-- nav-title -->
            

                <div class="navigation-bar">
            

            <main>
              









            </main>

              </div><!-- navigation-bar -->

        
       



      </div><!-- user-settings -->


  </div><!-- customer-profile -->
</div><!-- body-page-admin -->


<!-- ---footer----------------------------------------footer-----------------------------------------------footer--------------------------------footer----------------------------->

   
<?php
    include('common/footeradmin.php');
?>