<?php
    include('common/headeradmin.php');
?>

<?php
    include('separatecss/successmsgstyle.php');
?>



<body>



	<div class="content">


	 <center>
	 	<br>
	 	<div class="messege clearfix">
	 		<br>
			<center><i class="far fa-check-circle fa-6x"></i></center>
			

			<center>
			<p>
				Congratulations! Your Addvertiesment hass been published.
				<br>
				Click here to View	
			</p>

			<br>

			<form method="POST" action="#"><button type="button" class="">View Recipt</button></form>

			</center>
		
		</div><!-- messege -->
	 </center>
	
		
	</div><!-- content -->

</body>


<?php
    include('common/footeradmin.php');
?>