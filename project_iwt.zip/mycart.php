

<?php
    include('common/headeradmin.php');
?>

<div class="shopping-cart" style="background:gray; width:100%; height:100px;">
<br>
       <center><h1>Shopping Cart</h1></center>
</div>


<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<?php
    include('config/connection.php');

    $sql = "SELECT  c.cartid,c.displayid,c.postid,c.servicename,c.providermail,c.date,c.person,c.unitprice,c.total,c.customermail
    ,r.fname,r.lname,r.email FROM mycart c,register r WHERE c.customermail='".@$_SESSION["email"]."' AND c.providermail = r.email   ";
    $qry = mysqli_query($con,$sql);
?>

 <div class="main-content" style=" width:100%;   background: #0F90A5;">
 
        
<br>

<div class="table clearfix" style="width:60%; height:100%;  margin-left:145px;  display:inline-block;">




    <table class="table table-striped"  style="width:100%; border-radius:3px; font-weight:bold;">

    <tbody>

    <?php
    $total = 0;
    while($row=mysqli_fetch_array($qry))
    {
  
    ?>

      <tr>
        <td><?php echo $row["servicename"]; ?></td>


        <form action="" method="POST">          
            <td><input type="date" name="wanteddate" style="width:160px;" value="<?php echo $row["date"];?>"></td>
            <td><input type="number" name="persons" class="form-control" style="width:50px; height:25px;" value="<?php echo $row["person"]; ?>"></td>
            <td>Rs:<?php echo $row["unitprice"]; ?></td>
            <td>Rs:<?php echo $row["total"]; ?></td>

        <td>
        <button  name="btnupdate" class="btn btn-warning" ><i class="far fa-edit"></i></button>
        <button type="button" name="btndelete" class="btn btn-danger"><i class="fas fa-trash"></i></button>
        <input type="hidden" name="cartid" value="<?php echo $row["cartid"]; ?>">
        <input type="hidden" name="unitprice" value=<?php echo $row["unitprice"]; ?>>
        
        </form>

        </td>
      </tr>
      
    <?php
         $total = $total + $row["total"];
    }
    ?>

            <?php
            if(isset($_POST["btnupdate"]))
            {
                $sqlupdate = "UPDATE mycart SET date='".$_POST["wanteddate"]."',person = '".$_POST["persons"]."'
                ,total = '".$_POST["unitprice"] * $_POST["persons"]."'  WHERE cartid = '".$_POST["cartid"]."' ";
                if(mysqli_query($con,$sqlupdate)){

                    echo '
                      <meta http-equiv="refresh" content="0" />
                    ';
                
                
                
                  }
            }

        ?>

    
    </tbody>
    
  </table>  



    </div> <!--table -->



    <div class="checkout clearfix" style="width:15%; height:250px; border-radius:5px; margin-left:65px;  display:inline-block;">
            <h4>Total : </h4>
            
            <h1 style="color:#C78C26; margin-top:none;">Rs <?php print("$total"); ?></h1>
            
            <button type="button" class="btn btn-dark btn-lg" style="width:220px;"><center>Checkout</center></button>



    </div> <!--checkout -->

    

 </div>   <!-- main-content -->







    


<?php
    include('separatecss/mycartstyle.php');
?>

<?php
    include('common/footeradmin.php');
?>