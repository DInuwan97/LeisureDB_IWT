<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">


	<link rel="stylesheet" type="text/css" href="css/Register.css">
	<link rel="stylesheet" type="text/css" href="css/reg.css">
	
</head>
<body>

</body>
</html>