
<head>
	<title></title>


		   <link rel="stylesheet" type="text/css" href="css/login.css">
		   <link rel="stylesheet" type="text/css" href="css/header.css">
<link rel="stylesheet" type="text/css" href="css/home.css">
<link rel="stylesheet" type="text/css" href="css/customer_profile.css">
<link rel="stylesheet" type="text/css" href="css/single.css">

</head>
