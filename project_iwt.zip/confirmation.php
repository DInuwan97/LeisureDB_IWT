<?php
    include('common/headeradmin.php');
?>
<?php
    include('separatecss/confirmationstyle.php');
?>



<body>

	<div class="paymet-head clearfix">
		<i class="fas fa-money-check-alt fa-4x"></i> <h1>  Paymet Confirmation</h1>
	</div><!-- paymet-head -->

	<div class="content">


	 <center>
	 	<br>
	 	<div class="messege clearfix">
	 		<br>
			<center><i class="far fa-check-circle fa-6x"></i></center>
			

			<center>
			<p>
				Congrats ! Your Order hass been Accepted.
				<br>
				Payment was Successful !	
			</p>



			<table border="0">
				<tr style="height: 35px;">
					<td style="width:100px;">Billing No:</td>
					<td style="width: 140px;">#4751AZ11QW</td>
				</tr>
				<tr style="height: 35px;">
					<td style="width:100px;">Cash</td>
					<td style="width: 140px;">Rs : 2500.00</td>
				</tr>
				<tr style="height: 35px;">
					<td style="width:100px;">Taxi No:</td>
					<td style="width: 140px;">WP - CAM - 9941</td>
				</tr>
			</table>

			<td><form method="POST" action="#"><button type="button" class="">Place Oder</button></form></td>

			</center>
		
		</div><!-- messege -->
	 </center>
	
		
	</div><!-- content -->

</body>

<?php
    include('common/footeradmin.php');
?>