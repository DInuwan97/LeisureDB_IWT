<?php
    include('common/headeradmin.php');
?>

<?php
    include('separatecss/contactstyle.php');
?>

<!-- ---------------------header------------------header--------------------header--------------------header---------------------header--------- -->


					<div class="content-main clearfix">

<center>
    <h1>CONTACT US</h1></center>

    <div class="content-left clearfix">

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3951.403636707571!2d80.75784231538883!3d7.957172494268695!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3afca1239433dcb5%3A0x762e72bb619aef0c!2sSigiriya+Lion+Rock!5e0!3m2!1sen!2slk!4v1533052641591" width="630" height="70%" frameborder="0" style="border:0" allowfullscreen></iframe>

        <center>
            <tr>
                <td><i class="fa fa-phone-square" style="font-size:30px;color:black"></i></td>
				<td></td>
                <td><a href="skype:0712184518?call">(+94) 71 2184 518</a></td>
            </tr>

            <tr>
                <td><i class="fa fa-envelope-square" style="font-size:30px;color:black"></i></td>
                <td></td>
                <td><a href="mailto:info@thirtyfirstsoftwares.com">info@thirtyfirstsoftwares.com</a></td>
            </tr>
        </center>

        <center> <font color="blue">Sign up below news letter for our new updates</font>
            <a href="#">

               <i class="fab fa-facebook-square fa-2x" id="fb"></i></a>

            <a href="#"><i class="fab fa-twitter-square fa-2x" style="color:DeepSkyBlue"></i></a>

            <a href="#"><i class="fas fa-rss-square fa-2x" style="color:OrangeRed"></i></a>
        </center>

    </div>

    <div class="content-right clearfix">
	 <div class="progress-container">
			<div class="progress-bar" id="myBar"></div>
			</div> 		
        <h2><u>Send Message</u></h2>
        <center> 
                <table style="height: 127px;" width="413">
                    <form><tbody>
                        <tr>
                            <td style="width: 120px;">Your Name:</td>
                            <td style="width: 199px;">
                                <input type="text" name="firstname">
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 120px;">Your Email:</td>
                            <td style="width: 199px;">
                                <input type="text" name="email">
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 120px;">Subject:</td>
                            <td style="width: 199px;">
                                <input type="text" name="subject">
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 120px;">Message:</td>
                            <td style="width: 199px;">
                                <textarea name="message"  placeholder="Write something.." style="height:170px"></textarea>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </br>
				<button type="submit" class="submitbtn" value="Submit">Submit</button>
            </form>
        </center>

    </div>

</div>



<!-- ---footer----------------------------------------footer-----------------------------------------------footer--------------------------------footer----------------------------->

<?php
    include('common/footeradmin.php');
?>