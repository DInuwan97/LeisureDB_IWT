<?php
    include('common/headeradmin.php');
?>

<?php
    include('separatecss/feedbackstyle.php');
?>

<!-- ---------------------header------------------header--------------------header--------------------header---------------------header--------- -->



<!-- slideshow images -->
<div id="image/beach"><img src="image/beach.jpg" alt="beach" width="100%" height="500px" class="slideshow"/>
<img src="image/image2.jpg" alt="beach" width="100%" height="500px" class="slideshow"/>
<img src="image/image3.jpg" alt="beach" width="100%" height="500px" class="slideshow"/>
<img src="image/image4.jpg" alt="beach" width="100%" height="500px" class="slideshow"/></div>

<div class="bgimg">


	<br><center><img src="image/feedback.jpg" class="feedback" style="box-shadow:12px 29px 81px 0px rgba(0,0,0,0.75)"/></center>
<!-- comment box -->
<form>
<p id="comment"></p>
<textarea id="words" rows="10" cols="20" placeholder="Add your review here..."></textarea><br>
<center><input type="button" onclick="getwords()" value="Enter" style="height:30px;width:200px;"/></center> <br>

</form>




</div>

<script type="text/javascript">
function getwords() {
	
	text = words.value;
	document.getElementById("comment").innerHTML += '<p>'+text
	document.getElementById("words").value = " "
}

var slideIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("slideshow");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > x.length) {slideIndex = 1} 
    x[slideIndex-1].style.display = "block"; 
    setTimeout(carousel, 5000); // Change image every 2 seconds
	

}
</script>	
</div><br>
						  




<!-- ---footer----------------------------------------footer-----------------------------------------------footer--------------------------------footer----------------------------->

    <?php
    include('common/footeradmin.php');
?>