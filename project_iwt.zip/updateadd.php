<!DOCTYPE html>

<?php
$directory_self=str_replace(basename($_SERVER['PHP_SELF']),
'',$_SERVER['PHP_SELF']);

$uploadHandler='http://'.$_SERVER['HTTP_HOST'].

$directory_self.'upload.processor2.php';

$max_file_size=3000000;

?>




<?php
    include('common/headeradmin.php');
?>

<?php
    include('separatecss/postaddstyle.php');
?>




<!-- ---------------------header------------------header--------------------header--------------------header---------------------header--------- -->





<form action="" method="POST">
        <div class="row">
              <div class="col-75">
                <input type="text" id="fname" name="searchid" placeholder="Search">
              </div>
              <div class="col-25">
                <input type="submit" name="btnsearch" value="Search">
              </div>
        </div>
</form>


<?php
  include('config/connection.php');

 
  if(isset($_POST["btnsearch"]))
  {
    $searchid = $_POST["searchid"];

    $sql = "SELECT * FROM postadd WHERE id = $searchid";
    $qry = mysqli_query($con,$sql);

    if($row=mysqli_fetch_array($qry)){

  }

?>




 <!--Content  Start - Manesha-->
  <div class="content">
    <h1>Post Your Advertisements</h1>



     <form action="<?php echo $uploadHandler;?>" enctype="multipart/form-data" method="POST">


      <div>
        <section class="container">
          <div class="leftContainer">

            <div class="row">
              <div class="col-25">
                <label>Service Type</label>
              </div>
              <div class="col-75">
                <input type="text" id="<?php echo $row["servicename"];?>" name="servicename" placeholder="<?php echo $row["servicename"];?>" value="<?php echo $row["servicename"];?>">
              </div>
            </div>

            <div class="row">
              <div class="col-25">
                <label>Service Description</label>
              </div>
              <div class="col-75">
                <textarea id="subject" name="description" placeholder="<?php echo $row["description"];?>" style="height:200px"><?php echo $row["description"];?></textarea>
              </div>
            </div>           
            <div class="row">
              <div class="col-25">
                <label>Service Category</label>
              </div>
              <div class="col-75">
                <select id="service" name="category">
                  <option value="Hikking">Hikking</option>
                  <option value="Swimming">Swimming</option>
                  <option value="Camping">Camping</option>
                </select>
              </div>
            </div>    
            <div class="row">
              <div class="col-25">
                <label>Cost Per Person</label>
              </div>
              <div class="col-75">
                <input type="text" id="cost" name="cost" placeholder="<?php echo $row["cost"];?>" value="<?php echo $row["cost"];?>">
              </div>
            </div>

            <div class="row">
              <div class="col-25">
                <label>Upload Image</label>
              </div>
              <div class="col-75">
                  <br>
              <input type="file" name="file">
              </div>
            </div>
     
            <input type="hidden" name="hiddenid" value="<?php echo $row["id"]; ?>">
    
            <div class="row">
              <input type="submit" name="btnupdate"  value="Request from Admin">
            </div>
            </form> 


          </div>

          <div class="rightContainer">
            <p><b>Provider Name</b></p>
            <p>Johon Frenando</p>

            <p><b>Account Number</b></p>
            <p>0713542345</p>

            <p><b>Email</b></p>
            <p>johnf@gmail.com</p>

            <p><b>Account number</b></p>
            <p>213123 32343 323 53 343</p>            
          </div>

        </section>
      </div>

    
  </div>
  <div></div>
  </div>


  <?php
  }

  ?>

  <?php

 /*include('config/connection.php');

    		if(isset($_POST["btnupdate"])){


          $servicename = $_POST['servicename'];
          $description = $_POST['description'];
          $category = $_POST['category'];
          $cost = $_POST['cost'];
          $searchid = $_POST['searchid'];
        
         // $file1 = $now.'-'.$_FILES[$fieldname]['name'];
         

          $sql1="UPDATE postadd SET servicename='".$_POST['servicename']."',description='".$_POST['description']."' 
          ,category='".$_POST['category']."' ,id='".$_POST['searchid']."',cost='".$_POST['cost']."' where id='". $_POST["searchid"]."'";
            
            
            //excute query
            if(mysqli_query($con,$sql1)){
              
            echo'
              <div class="alert alert-success" role="alert" style="font-size:40px">
              Thank You '.$_POST["searchid"].'	You will recieve E-mail after a short while!
              </div>
                       
            ';
              
              
              
              
            }
            else{
              echo'
             Unsuccess
                       
            ';
            }
                   
        }*/

  ?>

                <br><br><br><br><br><br><br><br><br></br>
                <br><br><br><br>


  <!--Content  End - Manesha-->

<!-- ---footer----------------------------------------footer-----------------------------------------------footer--------------------------------footer----------------------------->
<?php
    include('common/footeradmin.php');
?>